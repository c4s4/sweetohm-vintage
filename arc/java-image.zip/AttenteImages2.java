/******************************************************************
* AttenteImages2 : exemple pour MygaleHebdo (C) Michel CASABIANCA *
******************************************************************/

import java.awt.*;

public class AttenteImages2 extends java.applet.Applet
{
	/** image � afficher */
  Image image;

  public void init()
  {
  	/* donne les r�f�rences de l'image */
    image=getImage(getDocumentBase(),"image.jpg");

		/* on cr�e le m�dia tracker, on y inscrit l'image et on la charge */
    MediaTracker tracker=new MediaTracker(this);
    tracker.addImage(image,0);
    try
    {
      tracker.waitForID(0);
    }
    catch(InterruptedException e) {}
  }

  public void paint(Graphics g)
  {
    g.drawImage(image,0,0,this);
  }
}