/******************************************************************
* AttenteImages3 : exemple pour MygaleHebdo (C) Michel CASABIANCA *
******************************************************************/

import java.awt.*;

public class AttenteImages3 extends java.applet.Applet
{
	/** image � afficher */
  Image image;

  public void init()
  {
  	/* donne les r�f�rences de l'image */
    image=getImage(getDocumentBase(),"image.jpg");
  }

  public void paint(Graphics g)
  {
    g.drawImage(image,0,0,this);
  }
}