/********************************************************************
* AttenteImages : exemple pour MygaleHebdo (C) Michel CASABIANCA    *
********************************************************************/

import java.awt.*;
import java.awt.image.*;

public class AttenteImages extends java.applet.Applet
{
	/** image � charger */
	Image image;
	
	/** on renseigne sur la localisation de l'image */
	public void init()
	{
		image=getImage(getDocumentBase(),"image.jpg");
	}
	
	/** routine d'affiche de l'applet : affiche l'image */
	public void paint(Graphics g)
	{
		/* si l'image ne peut encore �tre affich�e, on affiche une message
		indiquant que l'image est en cours de chargement */
		if(!g.drawImage(image,0,0,this))
		{
			g.drawString("Image en cours de chargement...",20,128);
		}
	}
	
	/** bloque l'affichage tant que l'image n'est pas charg�e */
	public boolean imageUpdate(Image img,int infoFlags,int x,int y,int width,int height)
	{
		/* on teste le flag de fin de chargement de l'image */
  	if((infoFlags & ImageObserver.ALLBITS)==ALLBITS)
  	{
  		/* si c'est OK, on affiche l'image */
    	repaint();
    	return false;
    }
		else
		{
			return true;
		}
	}
}