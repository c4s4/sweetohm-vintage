/********************************************************************
* EnvoyerMails pour GraineDeJava du 3.7.97 (C) Michel CASABIANCA    *
********************************************************************/

import java.net.*;
import java.io.*;
import java.util.*;
import java.applet.*;
import java.awt.*;

public class EnvoyerMails extends Applet
{
	/** hote du serveur SMTP */
	protected String hote;
	/** port utilis� par le serveur SMTP (en g�n�ral 25) */
	protected int port=25;
	/** adresse ou doit �tre e,voy� le mail */
	protected String destinataire="Destinataire";
	/** adresse de l'exp�diteur */
	protected String expediteur="Exp�diteur";
	/** fichier en param�tre de ligne de commande */
	protected String sujet="Sujet";
  /** Message � envoyer */
  protected String message="message";
	/** socket de la connexion au serveur */
	protected Socket socket;
	/** stream de sortie du socket */
  protected DataOutputStream sortie;
  /** message de copyright */
  static final protected String
  copyright="EnvoyerMails (C) Michel CASABIANCA - casa@sdv.fr";
  /** champ de saisie de l'adresse de destination */
  TextField champDestinataire=new TextField(destinataire);
  /** champ de saisie de l'adresse de l'exp�diteur */
  TextField champExpediteur=new TextField(expediteur);
  /** champ de saisie ddu sujet */
  TextField champSujet=new TextField(sujet);
  /** zone de saisie pour le message */
  TextArea zoneMessage=new TextArea(message);
  /** bouton pour envoyer le mail */
  Button boutonEnvoyer=new Button("Envoyer le message");
	
	/** init initialise l'interface */
	public void init()
	{
		/* Affichage message copyright */
    showStatus(copyright);
    /* initialisation de l'interface */
    setLayout(new BorderLayout());
    Panel barreAdresse=new Panel();
    barreAdresse.setLayout(new GridLayout(1,2));
    barreAdresse.add(champDestinataire);
    barreAdresse.add(champExpediteur);
    Panel barreHaut=new Panel();
    barreHaut.setLayout(new GridLayout(2,1));
    barreHaut.add(barreAdresse);
    barreHaut.add(champSujet);
    add("North",barreHaut);
    add("Center",zoneMessage);
    add("South",boutonEnvoyer);
    /* r�cup�ration de l'adresse du serveur */
    hote=getCodeBase().getHost();
  }
  
  /** envoie le mail, suppose que tous les champs ont �t� remplis */
  void envoyerMessage()
  {
  	/* r�cup�ration des donn�es saisies dans les champs */
  	destinataire=champDestinataire.getText();
  	expediteur=champExpediteur.getText();
  	sujet=champSujet.getText();
  	message=zoneMessage.getText();
		try
		{
			/* connexion au serveur */
  		socket=new Socket(hote,port);
    	sortie=new DataOutputStream(new 
    		BufferedOutputStream(socket.getOutputStream()));
    	/* envoie des donn�es */
    	sortie.writeBytes("MAIL FROM: "+expediteur+"\n");
    	sortie.writeBytes("RCPT TO: "+destinataire+"\n");
    	sortie.writeBytes("DATA\n");
    	sortie.writeBytes("From: "+expediteur+"\n");
    	sortie.writeBytes("To: "+destinataire+"\n");
    	sortie.writeBytes("Subject: "+sujet+"\n");
    	sortie.writeBytes("Date: "+(new Date()).toGMTString()+"\n\n");
    	sortie.writeBytes(message);
    	sortie.writeBytes("\n.\n");
    	sortie.flush();
    }
    catch(IOException e)
    {    	
			System.out.println("Erreur lors de la connexion au serveur :");
			e.printStackTrace();
    }
	}
	
	/** gestionnaire d'�v�nements */
	public boolean action(Event evt,Object arg)
	{
		if(evt.target==boutonEnvoyer)
		{
			envoyerMessage();
			return true;
		}
		else
		{
			return false;
		}
	}
}