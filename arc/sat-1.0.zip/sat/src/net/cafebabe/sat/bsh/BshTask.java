/*
 *  The Apache Software License, Version 1.1
 *
 *  Copyright (c) 2000 The Apache Software Foundation.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Apache Software Foundation (http://www.apache.org/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. The names "Apache" and "Apache Software Foundation" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact apache@apache.org.
 *
 *  5. Products derived from this software may not be called "Apache",
 *  nor may "Apache" appear in their name, without prior written
 *  permission of the Apache Software Foundation.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package net.cafebabe.sat.bsh;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.Reader;
import java.util.StringTokenizer;
import java.util.Vector;
import bsh.ConsoleInterface;
import bsh.EvalError;
import bsh.Interpreter;
import net.cafebabe.sat.util.FileTask;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
//import bsh.NameCompletion;

/**
 *  This task executes a Beanshell script within an Ant script. See
 *  documentation for this task usage.
 *
 * @author     Michel CASABIANCA
 */
public class BshTask
    extends FileTask
    implements ConsoleInterface {

    /**
     *  Reset flag. If this flag is <code>true</code>, the BSH interpreter is
     *  reseted for each script. If it is set to <code>false</code>, the fields
     *  and functions are persistent between BSH elements (but args are set to
     *  null anyway).
     */
    boolean reset = true;
    /**
     *  The list of arguments to pass to the script. This list behave the same
     *  as if it was passed on the command line to the script, but the values
     *  are come separated.
     */
    String[] args;
    /**
     *  The nested script to process. This value is null if no script is nested
     *  in the <bsh> element.
     */
    String script;
    /**
     *  The BSH interpreter. Only one interpreter is necessary for all BSH
     *  tasks, that is why this field is static.
     */
    static Interpreter interpreter;

    /**
     *  Reset flag setter.
     *
     * @param  reset  The flag value.
     */
    public void setReset(boolean reset) {
        this.reset = reset;
    }


    /**
     *  Set command line arguments for the script.
     *
     * @param  args  The coma separated of command line arguments.
     */
    public void setArgs(String args) {
        StringTokenizer st = new StringTokenizer(args, ",");
        this.args = new String[st.countTokens()];
        // extract the coma separated list of arguments
        for(int i = 0; i < this.args.length; i++) {
            this.args[i] = st.nextToken();
        }
    }


    /**
     *  Add text to the script to process.
     *
     * @param  text  The text to add to the script.
     */
    public void addText(String text) {
        if(script == null)
            script = text;
        else
            script += text;
    }


    /**  Processing method for the task. */
    public void execute() {
        // instanciate the interpreter if necessary
        if(interpreter == null || reset) {
            interpreter = new Interpreter();
            interpreter.setConsole(this);
        }
        try {
            // insert the args in the interpreter
            if(args != null) {
                // print the argument list
                String message = "Arguments:";
                for(int i = 0; i < args.length; i++) {
                    message += " " + args[i];
                }
                log(message);
                BshTask.interpreter.set("bsh.args", args);
            }
            // pass the the Ant project to the Beanshell interpreter
            BshTask.interpreter.set("antProject", getProject());
            // process a script
            Object value = null;
            if(script != null) {
                log("Executing nested script...", Project.MSG_VERBOSE);
                value = interpreter.eval(script);
            }
            // process source files
            Vector files = getFiles(false);
            for(int i = 0; i < files.size(); i++) {
                File file = (File)files.elementAt(i);
                log("Executing script " + file.getPath() + "...",
                    Project.MSG_VERBOSE);
                value = interpreter.source(file.getAbsolutePath());
            }
            // delete the command line arguments
            BshTask.interpreter.set("bsh.args", null);
            // print the value returned by the interpreter
            if(value != null) {
                // test for an exception (that should be rethrown)
                if(value instanceof BuildException)
                    throw (BuildException)value;
                // else print
                else
                    log(value.toString());
            }
        } // source file not found
        catch(FileNotFoundException e) {
            throw new BuildException("Script " + e.getMessage() +
                " not found.");
        } // error sourcing script
        catch(IOException e) {
            throw new BuildException("Error sourcing Script " +
                e.getMessage() + ".");
        } // error executing the script
        catch(EvalError e) {
            StringTokenizer st = new StringTokenizer(e.getMessage(), "\n");
            while(st.hasMoreElements()) {
                log(st.nextToken());
            }
            throw new BuildException("Error executing script.");
        }
    }


    /**
     *  A log method that avoid message mixing with synchronization.
     *
     * @param  message  The message to log.
     */
    public synchronized void log(String message) {
        super.log(message.trim());
    }

    // The following methods implement the ConsoleInterface to trap
    // Beanshell outputs
    /**
     *  Gets the in attribute of the BshTask object
     *
     * @return    The in value
     */
    public Reader getIn() {
        return null;
    }


    /**
     *  Gets the out attribute of the BshTask object
     *
     * @return    The out value
     */
    public PrintStream getOut() {
        return null;
    }


    /**
     *  Gets the err attribute of the BshTask object
     *
     * @return    The err value
     */
    public PrintStream getErr() {
        return null;
    }


    /**
     *  Description of the Method
     *
     * @param  message  Description of the Parameter
     */
    public void println(String message) {
        log(message);
    }


    /**
     *  Description of the Method
     *
     * @param  message  Description of the Parameter
     */
    public void print(String message) {
        log(message);
    }


    /**
     *  Description of the Method
     *
     * @param  message  Description of the Parameter
     */
    public void error(String message) {
        log(message);
    }
    // Those methods were deprecated in from version 1.1a16
    //public void print(String message,Color color) {log(message);}
    //public void setNameCompletion(NameCompletion nameCompletion) {}
}

