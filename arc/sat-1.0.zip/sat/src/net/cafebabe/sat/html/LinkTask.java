/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.cafebabe.sat.html;

import java.io.*;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit.ParserCallback;
import javax.swing.text.html.parser.ParserDelegator;
import net.cafebabe.sat.util.FileTask;
import org.apache.tools.ant.BuildException;
import sun.net.www.protocol.file.FileURLConnection;
import sun.net.www.protocol.ftp.FtpURLConnection;
//import sun.net.www.protocol.gopher.GopherURLConnection;

/**
 * This task checks links in HTML files.
 *
 * @author <a href="mailto:casa@sweetohm.net">Michel CASABIANCA</a>
 * @version 1.0
 */
public class LinkTask extends FileTask {
        
    /** External files check flag */
    boolean external;
    /** Interruption flag */
    boolean interrupt;
    /** Interruption requested */
    boolean interrupted;
    /** Log file name */
    String log;
    /** Log writer */
    Writer logWriter;
    /** Debug flag */
    boolean debug;
    /** SGML parser to parse HTML */
    ParserDelegator delegator;
    /** The parser */
    Parser parser;
    /** The file being parsed */
    File parsedFile;
    /** Cache for OK URLs */
    Hashtable okCache= new Hashtable();
    /** Cache for KO URLs */
    Hashtable koCache= new Hashtable();
    /** Response code for OK */
    static final int OK= 200;
    /** Indentation block */
    static final String INDENT= "  ";
    /** Ignore charset when parsing */
    boolean ignoreCharSet= true;
        
    /**
         * Creates a new <code>LinkTask</code> instance.
         */
    public LinkTask() {
                // instantiate the parser
                delegator= new ParserDelegator();
                // instanciate the document handler
                parser= new Parser();
    }
        
    /**
         * External files check setter.
         *
         * @param external A boolean indicating if external links should be
         * checked.
         */
    public void setExternal(boolean external) {
                this.external= external;
    }
        
    /**
         * Interrupt setter.
         *
         * @param interrupt
         */
    public void setInterrupt(boolean interrupt) {
                this.interrupt= interrupt;
    }
        
    /**
         * Log file setter.
         *
         * @param log A <code>String</code> that is the file name of the log.
         */
    public void setLog(String log) {
                this.log= log;
    }
        
    /**
         * Debug flag.
         *
         * @param debug A <code>boolean</code> that indicates if debug should
         * be displayed.
         */
    public void setDebug(boolean debug) {
                this.debug= debug;
    }
        
    /**
         * Indicates if the parser should ignore charset when parsing.
         * Defaults to true.
         *
         * @param ignoreCharSet A <code>boolean</code> that indicates if
         * charset should be ignored when parsing.
         */
    public void setIgnoreCharSet(boolean ignoreCharSet) {
                this.ignoreCharSet= ignoreCharSet;
    }
        
    /**
         * The method to launch the program as an Ant task.
         */
    public void execute() {
                // reset interruption flag
                interrupted= false;
                // open the log writer
                if (log != null) {
                        try {
                                logWriter= new FileWriter(getProject().resolveFile(log));
                        } catch (IOException e) {
                                throw new BuildException("Unable to open the log file");
                        }
                }
                // get the files to process
                Vector files= getFiles(true);
                // loop on files
                for (int i= 0; i < files.size(); i++) {
                        parsedFile= (File) files.elementAt(i);
                        // print message
                        log("Checking: " + parsedFile + "...");
                        try {
                                Reader reader= new FileReader(parsedFile);
                                delegator.parse(reader, parser, ignoreCharSet);
                        } catch (Exception e) {
                                if (debug)
                                        e.printStackTrace();
                                throw new BuildException("Error parsing file " + parsedFile);
                        }
                        if (interrupted)
                                throw new BuildException("Broken Link");
                }
                // close the log writer
                if (log != null) {
                        try {
                                logWriter.close();
                        } catch (IOException e) {
                                throw new BuildException("Unable to close the log file");
                        }
                }
    }
        
    /**
         * This method is called when an opening tag is met.
         *
         * @param tag An <code>HTML.Tag</code> object that is the tag.
         * @param attrSet An <code>MutableAttributeSet</code> that lists
         * attributes.
         */
    void startTag(HTML.Tag tag, MutableAttributeSet attrSet) {
                // test tag <a href="...">
                if (tag == HTML.Tag.A
                        && attrSet.getAttribute(HTML.Attribute.HREF) != null)
                        testURL((String) attrSet.getAttribute(HTML.Attribute.HREF));
                        // test tag <img src="...">
                else if (
                        tag == HTML.Tag.IMG
                        && attrSet.getAttribute(HTML.Attribute.SRC) != null)
                        testURL((String) attrSet.getAttribute(HTML.Attribute.SRC));
                        // test tag <area href="...">
                else if (
                        tag == HTML.Tag.AREA
                        && attrSet.getAttribute(HTML.Attribute.HREF) != null)
                        testURL((String) attrSet.getAttribute(HTML.Attribute.HREF));
                        // test tag <body background="...">
                else if (
                        tag == HTML.Tag.BODY
                        && attrSet.getAttribute(HTML.Attribute.BACKGROUND) != null)
                        testURL((String) attrSet.getAttribute(HTML.Attribute.BACKGROUND));
    }
        
    /**
         * This method test a given URL.
         *
         * @param location The URL to test as a <code>String</code>.
         */
    void testURL(String location) {
                if (debug)
                        log(INDENT + location);
                try {
                        URL fileURL= parsedFile.toURL();
                        URL url= new URL(fileURL, location);
                        URLConnection connection= url.openConnection();
                        // check a file URL
                        if (connection instanceof FileURLConnection) {
                                FileURLConnection fileConnection=
                                        (FileURLConnection) connection;
                                fileConnection.connect();
                                fileConnection.close();
                        }
                                // check an HTTP URL
                        else if (connection instanceof HttpURLConnection) {
                                if (external) {
                                        if (koCache.get(location) != null)
                                                throw new IOException();
                                        else if (okCache.get(location) == null) {
                                                HttpURLConnection httpConnection=
                                                        (HttpURLConnection) connection;
                                                httpConnection.connect();
                                                int code= httpConnection.getResponseCode();
                                                httpConnection.disconnect();
                                                if (code != OK)
                                                        throw new IOException();
                                                okCache.put(location, new Object());
                                        }
                                }
                        }
                                // check an FTP URL
                        else if (connection instanceof FtpURLConnection) {
                                if (external) {
                                        if (koCache.get(location) != null)
                                                throw new IOException();
                                        else if (okCache.get(location) == null) {
                                                FtpURLConnection ftpConnection=
                                                        (FtpURLConnection) connection;
                                                ftpConnection.connect();
                                                ftpConnection.close();
                                                okCache.put(location, new Object());
                                        }
                                }
                        }
                                // check a Gopher URL (not public !)
                                /*
                                 else if(connection instanceof GopherURLConnection && external) {
                                 GopherURLConnection gopherConnection=(GopherURLConnection)
                                 connection;
                                 gopherConnection.connect();
                                 gopherConnection.close();
                                 }
                                 */
                                // print the unknown URL protocol if debug
                        else if (debug) {
                                log(
                                        INDENT
                                                + INDENT
                                                + "Unknown protocol "
                                                + connection.getClass().getName());
                        }
                        // the URL is OK
                } catch (Exception e) {
                        // the URL is KO
                        if (debug)
                                e.printStackTrace();
                        log(INDENT + "Broken link " + location);
                        if (interrupt)
                                interrupted= true;
                }
    }
        
    /**
         * This method logs a message. This message is sent to the log method
         * of the ancestor and (if log was set) written in a log file.
         *
         * @param message The <code>String</code> message to write.
         */
    public void log(String message) {
                super.log(message);
                if (logWriter != null) {
                        try {
                                logWriter.write(message + '\n');
                                logWriter.flush();
                        } catch (IOException e) {
                                throw new BuildException("Unable to log");
                        }
                }
    }
        
    /**
         * This class handles parser callbacks.
         */
    class Parser extends ParserCallback {
                public void handleStartTag(
                        HTML.Tag tag,
                        MutableAttributeSet attrSet,
                        int pos) {
                        startTag(tag, attrSet);
                }
                public void handleSimpleTag(
                        HTML.Tag tag,
                        MutableAttributeSet attrSet,
                        int pos) {
                        startTag(tag, attrSet);
                }
    }
}
