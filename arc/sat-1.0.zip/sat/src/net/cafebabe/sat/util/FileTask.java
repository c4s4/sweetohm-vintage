/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.cafebabe.sat.util;

import java.io.File;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.Vector;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.FileSet;

/**
 * This is the ancestor of all the file related tasks. It manages file and
 * dir attributes and fileset nested elements.
 *
 * @author Michel CASABIANCA
 */
public abstract class FileTask
    extends Task {
    
    /** The coma separated list of files to process */
    String file;
    /** The coma separated list of directories to process */
    String dir;
    /** The <code>Vector</code> of filesets to process */
    Vector filesets=new Vector();
    
    /**
     * File attribute. This is a coma separated list of files to process.
     *
     * @param file The coma separated list of files to process.
     */
    public void setFile(String file) {
        this.file= file;
    }
    
    /**
     * Dir attribute. This is a coma separated list of directories to process.
     * All the files in the directory are processed. Subdirectories are not
     * scanned.
     *
     * @param dir The coma separated list of directories to process.
     */
    public void setDir(String dir) {
        this.dir= dir;
    }
    
    /**
     * Fileset nested element. The fileset is added to the list.
     *
     * @param fileset The fileset to add.
     */
    public void addFileset(FileSet fileset) {
        filesets.addElement(fileset);
    }
    
    /**
     * Return the list of files to process. This is a <code>Vector</code>
     * built from the files, directories and filesets of the task.
     *
     * @param strict A flag that indicates if we should check that at
     * least one file or directory is set. If false, the files and
     * directories are checked anyway.
     * @return A <code>Vector</code> of <code>File</code>s.
     */
    public Vector getFiles(boolean strict)
        throws BuildException {
        // test that there is at least one file to process
        if (strict) {
            if (file == null && dir == null && filesets.size() == 0)
                throw new BuildException(
                                         "Specify at least one source - "
                                         + "a file, dir or a fileset.");
        }
        // the list of files to process
        Vector files= new Vector();
        // extract the list of files
        if (file != null) {
            StringTokenizer st= new StringTokenizer(file, ",");
            int nbFiles= st.countTokens();
            // add each file to the list of files
            for (int i= 0; i < nbFiles; i++) {
                // test that the file exists
                File file= getProject().resolveFile(st.nextToken());
                if (!file.exists())
                    throw new BuildException("File " + file + " not found.");
                files.addElement(file);
            }
        }
        // extract the list of directories
        if (dir != null) {
            StringTokenizer st= new StringTokenizer(dir, ",");
            int nbDirs= st.countTokens();
            // process each directory
            for (int i= 0; i < nbDirs; i++) {
                // list files in the directory
                File dir= getProject().resolveFile(st.nextToken());
                // test that the dir exists
                if (!dir.exists())
                    throw new BuildException(
                                             "Directory " + dir + " not found.");
                // if directory doesn't exist, skip
                if (!dir.exists())
                    continue;
                String[] list= dir.list();
                for (int j= 0; j < list.length; j++) {
                    // add each file to the list
                    if (!((new File(dir,list[j])).isDirectory()))
                        files.addElement(new File(dir, list[j]));
                }
            }
        }
        // scan the filesets
        for (int i= 0; i < filesets.size(); i++) {
            // extract the fileset
            FileSet fileset= (FileSet) filesets.elementAt(i);
            // build the DirectoryScanner for the fileset
            DirectoryScanner ds= fileset.getDirectoryScanner(project);
            ds.scan();
            String[] list= ds.getIncludedFiles();
            for (int j= 0; j < list.length; j++)
                files.addElement(new File(ds.getBasedir(), list[j]));
        }
        // return the list of files
        return files;
    }
    
    /**
     * Return the list of files that are newer than the reference file.
     *
     * @param strict States if an error should be raised if no file is found.
     * @param reference The reference file to check dates against as a File
     * @return The filtered file list as a Vector
     */
    public Vector getNewFiles(boolean strict,File timeFile) {
        if(timeFile==null) return getFiles(strict);
        long referenceDate=timeFile.lastModified();
        Vector newFiles=new Vector();
        Vector files=getFiles(strict);
        for(int i=0;i<files.size();i++) {
            if(((File) files.elementAt(i)).lastModified()>referenceDate) {
                newFiles.addElement(files.elementAt(i));
            }
        }
        return newFiles;
    }
    
    /**
     * Tell if files were modified since the reference was generated. Useful
     * for the merge task for instance because it is not necessary to merge
     * again if no file was modified (or added) since the resulting file was
     * generated.
     *
     * @param reference The reference as a File
     * @return The reponse as a boolean
     */
    public boolean newerFilesThan(File timeFile) {
        if(!timeFile.exists()) return true;
        long referenceDate=timeFile.lastModified();
        Vector files=getFiles(false);
        for(int i=0;i<files.size();i++) {
            if(((File) files.elementAt(i)).lastModified()>referenceDate)
                return true;
        }
        return false;
    }
}
