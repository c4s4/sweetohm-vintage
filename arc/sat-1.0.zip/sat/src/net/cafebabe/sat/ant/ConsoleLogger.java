/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000-2002 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowlegement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "Ant" and "Apache Software
 *    Foundation" must not be used to endorse or promote products derived
 *    from this software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache"
 *    nor may "Apache" appear in their names without prior written
 *    permission of the Apache Group.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

package net.cafebabe.sat.ant;

import java.io.PrintStream;
import org.apache.tools.ant.BuildEvent;
import org.apache.tools.ant.BuildLogger;
import org.apache.tools.ant.Project;

/**
 * Writes build events to a PrintStream.
 *
 * @author Michel Casabianca
 */
public class ConsoleLogger
    implements BuildLogger {
    
    /** PrintStream to write non-error messages to */
    private PrintStream out;
    /** PrintStream to write error messages to */
    private PrintStream err;
    /** Lowest level of message to write out */
    private int level=Project.MSG_ERR;
    
    /**
     * Empty constructor.
     */
    public ConsoleLogger() {}
    
    /**
     * Constructor with streams and logging level.
     *
     * @param out The standard output stream as a PrintStream
     * @param err The error output stream as a PrintStream
     * @param level Ouput message logging level as an int
     */
    public ConsoleLogger(PrintStream out,PrintStream err,int level) {
        this.out=out;
        this.err=err;
        this.level=level;
    }
    
    /**
     * Sets the highest level of message this logger should respond to.
     *
     * @param level the logging level for the logger.
     */
    public void setMessageOutputLevel(int level) {
        this.level=level;
    }
    
    /**
     * Sets the output stream to which this logger is to send its output.
     *
     * @param output The output stream for the logger.
     */
    public void setOutputPrintStream(PrintStream output) {
        this.out = new PrintStream(output, true);
    }
    
    /**
     * Sets the output stream to which this logger is to send error messages.
     *
     * @param err The error stream for the logger.
     */
    public void setErrorPrintStream(PrintStream err) {
        this.err = new PrintStream(err, true);
    }
    
    /**
     * Logs a message to say that the target has started if this
     * logger allows information-level messages.
     *
     * @param event An event with any relevant extra information.
     *              Must not be <code>null</code>.
     */
    public void targetStarted(BuildEvent event) {
        if (Project.MSG_INFO <= level)
            out.println(event.getTarget().getName()+":");
    }
    
    /**
     * Logs a message, if the priority is suitable.
     *
     * @param event A BuildEvent containing message information.
     */
    public void messageLogged(BuildEvent event) {
        int priority = event.getPriority();
        if (priority <= level) {
            if (priority != Project.MSG_ERR)
                out.println(event.getMessage());
            else
                err.println(event.getMessage());
        }
    }
    
    public void setEmacsMode(boolean emacsMode) {}
    public void buildStarted(BuildEvent event) {}
    public void buildFinished(BuildEvent event) {}
    public void targetFinished(BuildEvent event) {}
    public void taskStarted(BuildEvent event) {}
    public void taskFinished(BuildEvent event) {}
}

