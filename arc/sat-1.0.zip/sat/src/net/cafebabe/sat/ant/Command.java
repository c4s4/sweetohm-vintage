/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.cafebabe.sat.ant;

import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Vector;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Target;

/**
 * Command implementation.
 *
 * @author Michel Casabianca.
 */
public class Command {
    
    /**
     * Describe the loaded project.
     *
     * @param project The Ant <code>Project</code>.
     * @param out The <code>PrintStream</code> to write to.
     */
    public static void desc(Project project,PrintStream out) {
        if(project==null) {
            out.println("No project loaded (use load command to load one)");
            return;
        } else {
            printDescription(project,out);
            printTargets(project,out);
        }
    }
    
    /**
     * Run a list of targets.
     *
     * @param project The loaded Project
     * @param targets The targets to run as a List
     * @param out The PrintStream to write to
     * @throws IOException
     */
    public static void targets(Project project,Vector targets,PrintStream out) {
        if(project==null) {
            out.println("No project loaded (use load command to load one)");
            return;
        }
        if (targets.size() > 0)
            project.executeTargets(targets);
        else
            project.executeTarget(project.getDefaultTarget());
    }
    
        /**
     * Print the project description, if any.
     *
     * @param project The Project to describe.
     * @param out The PrintStream to write description to.
     */
    private static void printDescription(Project project,PrintStream out) {
        if (project.getDescription() != null) {
            out.println(project.getDescription());
        }
    }
    
    /**
     * Print the project targets description.
     *
     * @param project The Project to describe.
     * @param out The PrintStream to write description to.
     */
    private static void printTargets(Project project,PrintStream out) {
        // find the target with the longest name
        int maxLength= 0;
        Enumeration ptargets=project.getTargets().elements();
        String targetName;
        String targetDescription;
        Target currentTarget;
        // split the targets in top-level and sub-targets depending
        // on the presence of a description
        Vector topNames= new Vector();
        Vector topDescriptions= new Vector();
        Vector subNames= new Vector();
        while (ptargets.hasMoreElements()) {
            currentTarget= (Target) ptargets.nextElement();
            targetName= currentTarget.getName();
            targetDescription= currentTarget.getDescription();
            // maintain a sorted list of targets
            if (targetDescription == null) {
                int pos= findTargetPosition(subNames, targetName);
                subNames.insertElementAt(targetName, pos);
            } else {
                int pos= findTargetPosition(topNames, targetName);
                topNames.insertElementAt(targetName, pos);
                topDescriptions.insertElementAt(targetDescription, pos);
                if (targetName.length() > maxLength) {
                    maxLength= targetName.length();
                }
            }
        }
        String defaultTarget= project.getDefaultTarget();
        if (defaultTarget != null
            && !"".equals(defaultTarget)) {
            Vector defaultName= new Vector();
            Vector defaultDesc= null;
            defaultName.addElement(defaultTarget);
            int indexOfDefDesc= topNames.indexOf(defaultTarget);
            if (indexOfDefDesc >= 0) {
                defaultDesc= new Vector();
                defaultDesc.addElement(topDescriptions.elementAt(indexOfDefDesc));
            }
            printTargets(defaultName,defaultDesc,"Default target:",
                         maxLength,out);
        }
        printTargets(topNames,topDescriptions,"Main targets:",
                     maxLength,out);
        printTargets(subNames, null,"Subtargets:", 0, out);
    }
    
    /**
     * Search for the insert position to keep names a sorted list of Strings
     *
     * @param names a  Vector
     * @param name a  String
     * @return   an int
     */
    private static int findTargetPosition(Vector names,String name) {
        int res= names.size();
        for (int i= 0; i < names.size() && res == names.size(); i++) {
            if (name.compareTo((String) names.elementAt(i)) < 0) {
                res= i;
            }
        }
        return res;
    }
    
    /**
     * Output a formatted list of target names with an optional description
     *
     * @param    names               a  Vector
     * @param    descriptions        a  Vector
     * @param    heading             a  String
     * @param    maxlen              an int
     * @param    out                 a  Writer
     * @throws   IOException
     */
    private static void printTargets(Vector names,
                                     Vector descriptions,
                                     String heading,
                                     int maxlen,
                                     PrintStream out) {
        if(names.size()==0) return;
        // now, start printing the targets and their descriptions
        String lSep= System.getProperty("line.separator");
        // got a bit annoyed that I couldn't find a pad function
        String spaces= "    ";
        while (spaces.length() < maxlen) {
            spaces += spaces;
        }
        StringBuffer msg= new StringBuffer();
        msg.append(heading+lSep);
        for (int i= 0; i < names.size(); i++) {
            msg.append(" ");
            msg.append(names.elementAt(i));
            if (descriptions != null) {
                msg.append(spaces.substring(0,maxlen-((String)
                                                      names.elementAt(i)).length()+2));
                msg.append(descriptions.elementAt(i));
            }
            msg.append(lSep);
        }
        out.print(msg.toString());
        out.flush();
    }
}

