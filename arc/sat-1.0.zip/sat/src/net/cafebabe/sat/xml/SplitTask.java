/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.cafebabe.sat.xml;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Vector;
import net.cafebabe.sat.util.FileTask;
import net.cafebabe.sat.util.IO;
import org.apache.tools.ant.BuildException;

/**
 * Split a file using dedicated processing instructions.
 *
 * @author <a href="mailto:casa@sweetohm.net">Michel CASABIANCA</a>
 */
public class SplitTask
    extends FileTask {
    
    /** Processing instruction to search */
    private String pattern= "split";
    /** Processing instruction to search for */
    private String pi="<?"+pattern;
    /** If a file is newer than the reference, it won't split */
    private File timeFile;
    
    /**
     * Empty constructor (needed for reflexion).
     */
    public SplitTask() {}
    
    /**
     * Pattern setter.
     *
     * @param pattern The pattern to search.
     */
    public void setPattern(String pattern) {
        this.pattern= pattern;
        pi="<?"+pattern;
    }
    
    /**
     * Set file for date reference.
     *
     * @param file The reference file as a String
     */
    public void setTimeFile(String file) {
        this.timeFile=new File(file);
    }
    
    /**
     * The method to launch the program as an Ant task.
     */
    public void execute() {
        Vector files=getNewFiles(true,timeFile);
        if(files.size()==0) return;
        log("Splitting "+files.size()+" files.");
        try {
            for (int i= 0;i<files.size();i++) {
                File file=(File) files.elementAt(i);
                processFile(file);
            }
            if(timeFile!=null) IO.writeFile((new Date()).toString(),timeFile);
        } catch (IOException e) {
            throw new BuildException("IO error: "+e.getMessage());
        }
    }
    
    /**
     * Process a single file
     *
     * @param file The file to process
     */
    private void processFile(File file)
        throws IOException {
        String string=IO.loadFile(file);
        if (string.indexOf(pi)>= 0) cutFile(string,file);
    }
    
    /**
     * Cut a file into parts delimited with the PI
     *
     * @param string The content of the file
     * @param file The file to cut
     */
    private void cutFile(String string,File file)
        throws IOException {
        int index=0;
        while((index=string.indexOf(pi,index))>=0) {
            int start=string.indexOf("\"",index) + 1;
            int end=string.indexOf("\"",start);
            String name=string.substring(start,end);
            name=file.getParent()+File.separator+name;
            start=string.indexOf(">",end)+1;
            end=string.indexOf(pi,end);
            index=string.indexOf(">",end)+1;
            IO.writeFile(string.substring(start,end),new File(name));
        }
    }
}
