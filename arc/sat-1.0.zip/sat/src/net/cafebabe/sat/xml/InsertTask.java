/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.cafebabe.sat.xml;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Vector;
import net.cafebabe.sat.util.FileTask;
import net.cafebabe.sat.util.IO;
import org.apache.tools.ant.BuildException;

/**
 * This task replace a given processing instruction with the
 * content of a given file.
 *
 * @author <a href="mailto:casa@sweetohm.net">Michel CASABIANCA</a>
 */
public class InsertTask
    extends FileTask {
    
    /** Processing instruction to search */
    private String pattern="insert";
    /** Processing instruction to search for */
    private String pi="<?"+pattern;
    /** The file to insert */
    private File source;
    /** Reference file for insertion */
    private File timeFile;
    
    /**
     * Empty constructor (needed for reflexion).
     */
    public InsertTask() {}
    
    /**
     * Pattern setter.
     *
     * @param pattern The pattern to search.
     */
    public void setPattern(String pattern) {
        this.pattern= pattern;
        pi= "<?" + pattern;
    }
    
    /**
     * Source setter.
     *
     * @param source The source file to insert.
     */
    public void setSource(String source) {
        this.source= getProject().resolveFile(source);
    }
    
    /**
     * Set file for date reference.
     *
     * @param file The reference file as a String
     */
    public void setTimeFile(String file) {
        this.timeFile=new File(file);
    }
    
    /**
     * The method to launch the program as an Ant task.
     */
    public void execute() {
        if(source==null)
            throw new BuildException("Source file is mandatory.");
        Vector files=getNewFiles(true,timeFile);
        if(files.size()==0) return;
        log("Inserting "+source+" in "+files.size()+" files.");
        String content=null;
        try {
            content=IO.loadFile(source);
            for (int i=0;i<files.size();i++) {
                File file=(File) files.elementAt(i);
                processFile(file,content);
            }
            if(timeFile!=null) {
                IO.writeFile((new Date()).toString(),timeFile);
            }
        } catch (IOException e) {
            throw new BuildException("IO error: " + e.getMessage());
        }
    }
    
    /**
     * Process a single file
     *
     * @param file The file to process
     */
    private void processFile(File file, String content)
        throws IOException {
        String string= IO.loadFile(file);
        if (string.indexOf(pi) >= 0)
            insert(string, file, content);
    }
    
    /**
     * Insert the PI with the content of the file
     *
     * @param string The content of the file
     * @param file The file to insert
     * @param source The content of the file to insert
     */
    private void insert(String string, File file, String content)
        throws IOException {
        int index= 0;
        while ((index=string.indexOf(pi,index))>=0) {
            int start=index;
            int end=string.indexOf(">",index)+1;
            index+=content.length()-(end-start);
            string=string.substring(0,start)+content+string.substring(end);
        }
        IO.writeFile(string, file);
    }
}
