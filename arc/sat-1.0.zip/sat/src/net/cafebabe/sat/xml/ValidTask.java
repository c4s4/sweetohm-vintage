/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.cafebabe.sat.xml;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Vector;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import net.cafebabe.sat.util.FileTask;
import net.cafebabe.sat.util.IO;
import org.apache.tools.ant.BuildException;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Valid is an XML validator (can check well formness and validity).
 *
 * @author Michel CASABIANCA
 */
public class ValidTask
    extends FileTask {
    
    /** DTD loading flag */
    private boolean dtd=true;
    /** Fail on error flag. If true, the ant compilation stops on error */
    private boolean failOnError=true;
    /** Warning error level */
    private static final int WARNING=0;
    /** Error error level */
    private static final int ERROR=1;
    /** Fatal error level */
    private static final int FATAL=2;
    /** The current error level */
    private int errorlevel= FATAL;
    /** The file prefix for system ID */
    private static final String FILE="file:";
    /** The number of errors */
    private int errorCount=0;
    /** The maximum number of errors */
    private int maxErrors=100;
    /** The reference file for date */
    private File timeFile;
    
    /**
     * Setter for the DTD loading. If true, the DTD is loaded for validation.
     * Defaults to true.
     *
     * @param dtd a <code>boolean</code> value
     */
    public void setDtd(boolean dtd) {
        this.dtd= dtd;
    }
    
    /**
     * Setter for the failonerror flag.If true, the Ant compilation stops
     * with an error message if the document being validated is not valid.
     * Defaults to true.
     *
     * @param failonerror Flag for failonerror flag.
     */
    public void setFailonerror(boolean failonerror) {
        this.failOnError= failonerror;
    }
    
    /**
     * Error level setter (possible values are 'warning', 'error' or 'fatal').
     * The default value is 'fatal'.
     *
     * @param errorlevel The error level.
     */
    public void setErrorlevel(String errorlevel) {
        if(errorlevel.equals("warning"))
            this.errorlevel= WARNING;
        else if(errorlevel.equals("error"))
            this.errorlevel= ERROR;
        else if(errorlevel.equals("fatal"))
            this.errorlevel= FATAL;
        else throw new
                BuildException("Illegal error level (possible values are "+
                               "'warning', 'error' or 'fatal')");
    }
    
    /**
     * Maximum errors setter.
     *
     * @param maxerrors The maximum number of errors to display for
     * a given file.
     */
    public void setMaxerrors(String maxerrors) {
        try {this.maxErrors= Integer.parseInt(maxerrors);}
        catch (NumberFormatException e) {
            throw new BuildException("The value of attribute 'maxerrors' "+
                                     "should be an integer.");
        }
        if (this.maxErrors<1)
            throw new BuildException("Max number of errors must be greater than 0.");
    }
    
    /**
     * Set file for date reference.
     *
     * @param file The reference file as a String
     */
    public void setTimeFile(String file) {
        this.timeFile=new File(file);
    }
    
    /**
     * Executes the task.
     *
     * @exception BuildException if an error occurs
     */
    public void execute()
        throws BuildException {
        SAXParser parser= getParser();
        Handler handler= new Handler();
        Vector files=getNewFiles(true,timeFile);
        for(int i=0;i<files.size();i++) {
            File file= (File) files.elementAt(i);
            log("Validating file '" + file.getName() + "'...");
            try {parser.parse(file, handler);}
            catch (SAXParsingInterruptedException e) {
                log(e.getMessage());
                if (failOnError)
                    throw new BuildException("Parsing error.");
            }
            catch (SAXException e) {
                throw new BuildException("Unknown error while parsing.");
            }
            catch (IOException e) {
                throw new BuildException("IO error while parsing.");
            }
            if(errorCount>0 && failOnError)
                throw new BuildException("Parsing error.");
        }
        if(timeFile!=null) {
            try{IO.writeFile((new Date()).toString(),timeFile);}
            catch(IOException e) {}
        }
    }
    
    /**
     * Builds the SAX parser for parsing.
     *
     * @return The built parser
     */
    private SAXParser getParser() {
        try {
            SAXParserFactory factory= SAXParserFactory.newInstance();
            factory.setValidating(dtd);
            return factory.newSAXParser();
        } catch (Exception e) {
            throw new BuildException(e.getMessage());
        }
    }
    
    /**
     * A class to handle parsing errors.
     */
    private class Handler
        extends DefaultHandler {
        
        /**
         * Manage warnings. Implements ErrorHandler interface.
         *
         * @param e The parsing exception as a SAXParseException
         * @exception SAXException
         */
        public void warning(SAXParseException e)
            throws SAXException {
            if (errorlevel <= WARNING)
                printError(e);
        }
        
        /**
         * Manage errors. Implements ErrorHandler interface.
         *
         * @param e The parsing exception as a SAXParseException
         * @exception SAXException
         */
        public void error(SAXParseException e)
            throws SAXException {
            if (errorlevel <= ERROR)
                printError(e);
        }
        
        /**
         * Manage fatal errors. Implements ErrorHandler interface.
         *
         * @param e The parsing exception as a SAXParseException
         * @exception SAXException
         */
        public void fatalError(SAXParseException e)
            throws SAXException {
            printError(e);
        }
        
        /**
         * Print and register the error.
         *
         * @param e The error as a SAXParseException
         * @exception SAXException
         */
        void printError(SAXParseException e)
            throws SAXException {
            errorCount++;
            if (errorCount>maxErrors)
                throw new SAXParsingInterruptedException();
            String systemId= e.getSystemId();
            if (systemId.startsWith(FILE))
                systemId= systemId.substring(FILE.length());
            int lineNumber= e.getLineNumber();
            String message= "";
            if (systemId != null)
                message += systemId + ":";
            if (lineNumber >= 0)
                message += lineNumber + ":";
            if (systemId != null || lineNumber >= 0)
                message += " ";
            log(message + e.getMessage());
        }
    }
    
    /**
     * This exception is thrown when the parsing is interrupted due to
     * to a number of errors greater than the allowed maximum.
     */
    private class SAXParsingInterruptedException
        extends SAXException {
        
        /**
         * Creates a new <code>SAXParsingInterruptedException</code> instance.
         * Simply fill the message.
         */
        SAXParsingInterruptedException() {
            super("Parsing interrupted.");
        }
    }
}
