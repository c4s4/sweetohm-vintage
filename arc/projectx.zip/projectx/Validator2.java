/*
 * (C) Copyright Michel Casabianca 1999  All rights reserved.
 *
 * The program is provided "as is" without any warranty express or
 * implied, including the warranty of non-infringement and the implied
 * warranties of merchantibility and fitness for a particular purpose.
 * The Copyright owner will not be liable for any damages suffered by
 * you as a result of using the Program. In no event will the Copyright
 * owner be liable for any special, indirect or consequential damages or
 * lost profits even if the Copyright owner has been advised of the
 * possibility of their occurrence.
 */

import org.xml.sax.*;
import org.xml.sax.helpers.*;

public class Validator2
{
    /** parser XML validant de ProjectX */
    private static final String parserClassName=
	"com.sun.xml.parser.ValidatingParser";

    /**
     * M�thode main
     *
     * @param args le fichier � valider
     */
    public static void main(String[] args) {
	try {
	    // on instancie le parser
	    Parser parser=ParserFactory.makeParser(parserClassName);
	    // on change la locale
	    parser.setLocale(new java.util.Locale("en","US"));
	    // on construit la source du fichier � valider
	    String fichier="file:"+
		System.getProperty("user.dir")+
		System.getProperty("file.separator")+
		args[0];
	    InputSource source=new InputSource(fichier);
	    // on parse le fichier
	    parser.parse(source);
	}
	// on intercepte les exceptions de type SAXParseException
	// qui encapsulent les messages d'erreur XML
	catch(SAXParseException e1) {
	    System.out.println(e1.getSystemId()+":"+
			       e1.getLineNumber()+":"+
			       e1.getMessage());
	}
	// on affiche les autres exceptions
	catch(Exception e2) {e2.printStackTrace();}
    }
}
