/********************************************************************
* AvecThread : exemple pour Mygale Hebdo (C) Michel CASABIANCA      *
********************************************************************/

import java.awt.*;
import java.util.*;

public class AvecThread extends java.applet.Applet implements Runnable
{
	String[] nom;
	Image[] image;
	Canvas ecran=new Canvas();
	Panel barreBoutons=new Panel();
	Button precedente=new Button(" < ");
	Button suivante=new Button(" > ");
	Button debut=new Button(" |< ");
	Button fin=new Button(" >| ");
	TextField compteur=new TextField(5);
	int index=0;
	Thread tache;
	
	/** initialisation de l'applet */
	public void init()
	{
		/* on charge la liste des noms des images */
		nom=decouperChaine(getParameter("images"),"|");
		image=new Image[nom.length];
		/* on initialise l'interface */
		setBackground(Color.lightGray);
		setLayout(new BorderLayout());
		add("Center",ecran);
		barreBoutons.add(debut);
		barreBoutons.add(precedente);
		barreBoutons.add(suivante);
		barreBoutons.add(fin);
		barreBoutons.add(compteur);
		add("South",barreBoutons);
		compteur.setEditable(false);
	}
		
	/** d�coupage d'une chaine en mots */
	String[] decouperChaine(String chaine,String separateur)
	{
		StringTokenizer st=new StringTokenizer(chaine,separateur);
		String[] mots=new String[st.countTokens()];
		for(int i=0;i<mots.length;i++)
		{
			mots[i]=st.nextToken();
		}
		return mots;
	}

	/** affiche l'image N�1, et on lance le chargement des suivantes */
	public void start()
	{
		afficherImage();
		tache=new Thread(this);
		tache.start();
	}
	
	/** charge les images une par une */
	public void run()
	{
		for(int i=0;i<nom.length;i++)
		{
			/* si l'image est d�j� charg�e, on passe � la suivante */
			if(image[i]!=null) continue;
			/* on charge l'image */
			image[i]=getImage(getDocumentBase(),nom[i]);
			/* on attend la fin de son chargement */
			MediaTracker mt=new MediaTracker(this);
			mt.addImage(image[i],0);
			try {mt.waitForID(0);}
			catch(InterruptedException e) {}
		}
	}
	
	/** gestion des �v�nements */
	public boolean action(Event evt,Object what)
	{
		if(evt.target==precedente)
		{
			index--;
			if(index<0) index=nom.length-1;
			afficherImage();
			return true;
		}
		else if(evt.target==suivante)
		{
			index++;
			if(index>=nom.length) index=0;
			afficherImage();
			return true;
		}
		else if(evt.target==debut)
		{
			index=0;
			afficherImage();
			return true;
		}
		else if(evt.target==fin)
		{
			index=nom.length-1;
			afficherImage();
			return true;
		}
		else return false;
	}
	
	/** affichage d'une image si elle est disponible */
	void afficherImage()
	{
		/* on affiche le num�ro de l'image dans le compteur */
		compteur.setText(index+1+" / "+nom.length);
		/* si l'image n'est pas charg�e, on la charge */
		if(image[index]==null)
		{
			image[index]=getImage(getDocumentBase(),nom[index]);
		}
		/* on affiche l'image demand�e */
		Graphics g=ecran.getGraphics();
		Rectangle r=ecran.bounds();
		g.drawImage(image[index],(r.width-image[index].getWidth(this))/2,
			(r.height-image[index].getHeight(this))/2,this);
	}
	
	/** dessine l'applet */
	public void paint(Graphics g)
	{
		afficherImage();
	}
}