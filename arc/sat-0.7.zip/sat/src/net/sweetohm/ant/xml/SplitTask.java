/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.sweetohm.ant.xml;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import net.sweetohm.ant.util.FileTask;
import net.sweetohm.ant.util.IO;
import org.apache.tools.ant.BuildException;

/**
 * Split a file using dedicated processing instructions.
 *
 * @author <a href="mailto:casa@sweetohm.net">Michel CASABIANCA</a>
 * @version 1.0
 */
public class SplitTask extends FileTask {
	
    /** Processing instruction to search */
    String pattern= "split";
    /** Processing instruction to search for */
    String pi= "<?" + pattern;
    /** Verbosity flag */
    boolean verbose= false;
    /** The list of files to process */
    Vector files= new Vector();
	
    /**
     * Empty constructor (needed for reflexion).
     */
    public SplitTask() {}
	
    /**
     * Pattern setter.
     *
     * @param pattern The pattern to search.
     */
    public void setPattern(String pattern) {
	this.pattern= pattern;
	pi= "<?" + pattern;
    }
	
    /**
     * The method to launch the program as an Ant task.
     */
    public void execute() {
	// get the files to process
	Vector files= getFiles(true);
	// test arguments
	if (files.size() == 0) {
	    throw new BuildException("At least one of the file or dir "+
				     "attributes, or a fileset element, "+
				     "must be set.");
	}
	// print message
	log("Splitting " + files.size() + " files.");
	// loop on the files of the list
	try {
	    for (int i= 0; i < files.size(); i++) {
		File file= (File) files.elementAt(i);
		// if the file is a directory
		if (file.isDirectory()) {
		    String[] list= file.list();
		    for (int j= 0; j < list.length; j++) {
			File file2= new File(file, list[j]);
			if (!file2.isDirectory())
			    processFile(file2);
		    }
		}
		// if file is a file
		else {
		    processFile(file);
		}
	    }
	} catch (IOException e) {
	    throw new BuildException("IO error: " + e.getMessage());
	}
    }
	
    /**
     * Process a single file
     *
     * @param file The file to process
     */
    void processFile(File file) throws IOException {
	// load the file in a string
	String string= IO.loadFile(file);
	// process the file if necessary
	if (string.indexOf(pi) >= 0)
	    cutFile(string, file);
    }
	
    /**
     * Cut a file into parts delimited with the PI
     *
     * @param string The content of the file
     * @param file The file to cut
     */
    void cutFile(String string, File file) throws IOException {
	// index of the PI in the file
	int index= 0;
	// loop on PIs
	while ((index= string.indexOf(pi, index)) >= 0) {
	    // build the resulting file name
	    int start= string.indexOf("\"", index) + 1;
	    int end= string.indexOf("\"", start);
	    String name= string.substring(start, end);
	    name= file.getParent() + File.separator + name;
	    // find the start and end of the piece
	    start= string.indexOf(">", end) + 1;
	    end= string.indexOf(pi, end);
	    index= string.indexOf(">", end) + 1;
	    // write the file on disk
	    IO.writeFile(string.substring(start, end), new File(name));
	}
    }
}
