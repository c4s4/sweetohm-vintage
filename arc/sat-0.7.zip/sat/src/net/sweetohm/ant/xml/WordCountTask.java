/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.sweetohm.ant.xml;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import net.sweetohm.ant.util.FileTask;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Count words in an XML document.
 *
 * @author Michel CASABIANCA
 * @version 1.0
 */
public class WordCountTask extends FileTask {

    /** The file prefix for system ID */
    static final String FILE= "file:";
    /** The set of separator characters (between two words) */
    String separators= " \t\n\r.,:;!?\"(){}[]+-*/=<>0123456789&#$�%|_@�";
    /** The SAX parser */
    SAXParser parser;
    /** The handler */
    Handler handler= new Handler();
    /** The list of elements to exclude */
    List excludeElements= new ArrayList();
    /** The list of elements which content is a single word */
    List singleElements= new ArrayList();
    /** The map of attributes to include (sorted by elements) */
    Map includeAttributes= new HashMap();
    /** The include stack (indicates if should include current element) */
    List include= new ArrayList();
    /** The number of words in the document being parsed */
    int nbWords;
    /** The number of files */
    int nbFiles;
    /** The property for the number of words */
    String property;
    /** The property for the number of files */
    String propertyFiles;
    /** Quiet flag (no message) */
    boolean quiet;

    /**
     * Creates a new <code>WordCountTask</code> instance.
     *
     * @exception ParserConfigurationException if an error occurs
     * @exception SAXException if an error occurs
     */
    public WordCountTask() throws ParserConfigurationException, SAXException {
        // get the parser factory
        SAXParserFactory factory= SAXParserFactory.newInstance();
        // set the parser non validating
        factory.setValidating(false);
        // get the SAX parser
        parser= factory.newSAXParser();
    }

    /**
     * Set the separator character list.
     *
     * @param separators The list of separators as a <code>String</code>.
     */
    public void setSeparators(String separators) {
        this.separators= separators;
    }

    /**
     * Set the list of excluded elements from the word count. The words 
     * contained in such elements are ignored.
     *
     * @param excludeList The coma separated list of elements to exclude as 
     * a <code>String</code>.
     */
    public void setExcludeElements(String excludeList) {
        StringTokenizer st= new StringTokenizer(excludeList.trim(), " ,");
        while (st.hasMoreTokens())
            excludeElements.add(st.nextToken().trim());
        log("Excluding elements: " + excludeElements, Project.MSG_DEBUG);
    }

    /**
     * Set the list of elements which content is considered a single word.
     *
     * @param singleList The coma separated list of single elements.
     */
    public void setSingleElements(String singleList) {
        StringTokenizer st= new StringTokenizer(singleList.trim(), " ,");
        while (st.hasMoreTokens())
            singleElements.add(st.nextToken().trim());
        log("Single elements: " + singleElements, Project.MSG_DEBUG);
    }

    /**
     * Set the list of attributes to include as a coma separated list.
     * Each attribute is noted as "element@attribute".
     *
     * @param includeList The coma separated list of attributes.
     */
    public void setIncludeAttributes(String includeList) {
        StringTokenizer st= new StringTokenizer(includeList.trim(), " ,");
        while (st.hasMoreTokens()) {
            String elatt= st.nextToken().trim();
            String element= elatt.substring(0, elatt.indexOf("@")).trim();
            String attribute= elatt.substring(elatt.indexOf("@") + 1).trim();
            List atts= (List) includeAttributes.get(element);
            if (atts == null)
                atts= new ArrayList();
            atts.add(attribute);
            includeAttributes.put(element, atts);
        }
        log("Excluding elements: " + excludeElements, Project.MSG_DEBUG);
    }

    /**
     * Load a properties file defining document properties, that is the lists
     * of elements to exclude, single elements, attributes to include and
     * separator characters.
     *
     * @param file The properties file as a <code>String</code>.
     */
    public void setDocumentProperties(String file) {
        Properties properties= new Properties();
        try {
            properties.load(
                new FileInputStream(getProject().resolveFile(file)));
        } catch (Exception e) {
            throw new BuildException(
                "Error loading the document " + "properties file");
        }
        if (properties.getProperty("separators") != null)
            setSeparators(properties.getProperty("separators") + " ");
        log(
            "Separators: " + properties.getProperty("separators"),
            Project.MSG_DEBUG);
        if (properties.getProperty("excludeElements") != null)
            setExcludeElements(properties.getProperty("excludeElements"));
        log(
            "Exclude Elements: " + properties.getProperty("excludeElements"),
            Project.MSG_DEBUG);
        if (properties.getProperty("singleElements") != null)
            setSingleElements(properties.getProperty("singleElements"));
        log(
            "Single Elements: " + properties.getProperty("singleElements"),
            Project.MSG_DEBUG);
        if (properties.getProperty("includeAttributes") != null)
            setIncludeAttributes(properties.getProperty("includeAttributes"));
        log(
            "Include Attributes: "
                + properties.getProperty("includeAttributes"),
            Project.MSG_DEBUG);
    }

    /**
     * Set the property where the word count is put.
     *
     * @param property The property to set.
     */
    public void setProperty(String property) {
        this.property= property;
        log("Property: " + property, Project.MSG_DEBUG);
    }

    /**
     * Set the property where to put the file count.
     *
     * @param propertyFiles The property to set.
     */
    public void setPropertyFiles(String propertyFiles) {
        this.propertyFiles= propertyFiles;
        log("Property for Files: " + property, Project.MSG_DEBUG);
    }

    /**
     * Indicates if the task should be quiet (no message for word and file
     * count).
     *
     * @param quiet The quiet flag.
     */
    public void setQuiet(boolean quiet) {
        this.quiet= quiet;
    }

    /**
     * Execute the task.
     *
     * @exception BuildException if an error occurs
     */
    public void execute() throws BuildException {
        // reset the number of words
        nbWords= 0;
        // reset the number of files
        nbFiles= 0;
        // get the files to process
        Vector files= getFiles(true);
        // loop on the files
        for (int i= 0; i < files.size(); i++) {
            // increment the number of files
            nbFiles++;
            // get the next file
            File file= (File) files.elementAt(i);
            log("Processing File: " + file, Project.MSG_DEBUG);
            // parse the file
            try {
                parser.parse(file, handler);
                // catch any exception
            } catch (Exception e) {
                e.printStackTrace();
                throw new BuildException("Error while parsing.");
            }
        }
        // set the properties
        if (property != null)
            project.setProperty(property, Integer.toString(nbWords));
        if (propertyFiles != null)
            project.setProperty(propertyFiles, Integer.toString(nbFiles));
        // print a message with word and file count
        if (!quiet)
            log(nbWords + " words in " + nbFiles + " file(s).");
    }

    /**
     * A class to handle content and parsing errors.
     */
    class Handler extends DefaultHandler {

        /**
         * This method is called when a new element is encountered.
         *
         * @param namespaceURI a <code>String</code> value
         * @param localName a <code>String</code> value
         * @param qName a <code>String</code> value
         * @param atts an <code>Attributes</code> value
         * @exception SAXException if an error occurs
         */
        public void startElement(
            String namespaceURI,
            String localName,
            String qName,
            Attributes atts)
            throws SAXException {
            // determine if should include text in this element
            boolean isIncluded= !excludeElements.contains(qName);
            // test if this element is single
            boolean isSingle= singleElements.contains(qName);
            if (isSingle) {
                nbWords++;
                isIncluded= false;
            }
            // if previous inclusion was false, propagate
            if (include.size() > 0
                && !((Boolean) include.get(include.size() - 1)).booleanValue())
                isIncluded= false;
            // set the include boolean on the stack
            include.add(new Boolean(isIncluded));
            log(
                "Include element " + qName + ": " + isIncluded,
                Project.MSG_DEBUG);
            // scan attributes
            List attList= (List) includeAttributes.get(qName);
            if (attList != null) {
                for (int i= 0; i < attList.size(); i++) {
                    String att= (String) attList.get(i);
                    String text= atts.getValue(att);
                    if (text != null)
                        countWords(text);
                }
            }

        }

        /**
         * This method is called when the end of an element is reached.
         *
         * @param namespaceURI a <code>String</code> value
         * @param localName a <code>String</code> value
         * @param qName a <code>String</code> value
         * @exception SAXException if an error occurs
         */
        public void endElement(
            String namespaceURI,
            String localName,
            String qName)
            throws SAXException {
            // remove the include on the top of the pile
            include.remove(include.size() - 1);
        }

        /**
         * This method is called when a text node is met.
         *
         * @param ch a <code>char[]</code> value
         * @param start an <code>int</code> value
         * @param length an <code>int</code> value
         * @exception SAXException if an error occurs
         */
        public void characters(char[] ch, int start, int length)
            throws SAXException {
            // test if we should include the text
            if (((Boolean) include.get(include.size() - 1)).booleanValue()) {
                String text= new String(ch, start, length);
                countWords(text);
            }
        }

        /**
         * Utility method to count words in a string.
         *
         * @param text a <code>String</code> value
         */
        void countWords(String text) {
            text= text.trim();
            if (text.length() == 0)
                return;
            StringTokenizer st= new StringTokenizer(text, separators);
            nbWords += st.countTokens();
        }

        /**
         * Manage warnings. Implements ErrorHandler interface.
         */
        public void warning(SAXParseException e) throws SAXException {
            printError(e);
        }

        /**
         * Manage errors. Implements ErrorHandler interface.
         */
        public void error(SAXParseException e) throws SAXException {
            printError(e);
        }

        /**
         * Manage fatal errors. Implements ErrorHandler interface.
         */
        public void fatalError(SAXParseException e) throws SAXException {
            printError(e);
        }

        /**
         * Print a validation error.
         */
        void printError(SAXParseException e) throws SAXException {
            // get error info
            String systemId= e.getSystemId();
            // remove "file:" from systemId
            if (systemId.startsWith(FILE))
                systemId= systemId.substring(FILE.length());
            int lineNumber= e.getLineNumber();
            String message= "";
            // add info if present
            if (systemId != null)
                message += systemId + ":";
            if (lineNumber >= 0)
                message += lineNumber + ":";
            if (systemId != null || lineNumber >= 0)
                message += " ";
            // print the error message
            log(message + e.getMessage());
        }
    }
}
