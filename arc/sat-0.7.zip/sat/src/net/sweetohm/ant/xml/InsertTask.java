/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.sweetohm.ant.xml;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import net.sweetohm.ant.util.FileTask;
import net.sweetohm.ant.util.IO;
import org.apache.tools.ant.BuildException;

/**
 * This task replace a given processing instruction with the
 * content of a given file.
 *
 * @author <a href="mailto:casa@sweetohm.net">Michel CASABIANCA</a>
 * @version 1.0
 */
public class InsertTask extends FileTask {

    /** Processing instruction to search */
    String pattern= "insert";
    /** Processing instruction to search for */
    String pi= "<?" + pattern;
    /** The list of files to process */
    Vector files= new Vector();
    /** The file to insert */
    File source;

    /**
     * Empty constructor (needed for reflexion).
     */
    public InsertTask() {}

    /**
     * Pattern setter.
     *
     * @param pattern The pattern to search.
     */
    public void setPattern(String pattern) {
        this.pattern= pattern;
        pi= "<?" + pattern;
    }

    /**
     * Source setter.
     *
     * @param source The source file to insert.
     */
    public void setSource(String source) {
        this.source= getProject().resolveFile(source);
    }

    /**
     * The method to launch the program as an Ant task.
     */
    public void execute() {
        // get the files to process
        Vector files= getFiles(true);
        // test source argument
        if (source == null)
            throw new BuildException("Source file is mandatory.");
        // print message
        log("Inserting " + source + " in " + files.size() + " files.");
        // load the source
        String content= null;
        try {
            content= IO.loadFile(source);
            // loop on the files of the list
            for (int i= 0; i < files.size(); i++) {
                File file= (File) files.elementAt(i);
                // if the file is a directory
                if (file.isDirectory()) {
                    String[] list= file.list();
                    for (int j= 0; j < list.length; j++) {
                        File file2= new File(file, list[j]);
                        if (!file2.isDirectory())
                            processFile(file2, content);
                    }
                }
                // if file is a file
                else {
                    processFile(file, content);
                }
            }
        } catch (IOException e) {
            throw new BuildException("IO error: " + e.getMessage());
        }
    }

    /**
     * Process a single file
     *
     * @param file The file to process
     */
    void processFile(File file, String content) throws IOException {
        // load the file in a string
        String string= IO.loadFile(file);
        // process the file if necessary
        if (string.indexOf(pi) >= 0)
            insert(string, file, content);
    }

    /**
     * Insert the PI with the content of the file
     *
     * @param string The content of the file
     * @param file The file to insert
     * @param source The content of the file to insert
     */
    void insert(String string, File file, String content) throws IOException {
        // index of the PI in the file
        int index= 0;
        // loop on PIs
        while ((index= string.indexOf(pi, index)) >= 0) {
            // find the start and end of the piece
            int start= index;
            int end= string.indexOf(">", index) + 1;
            index += content.length() - (end - start);
            // build the new file content
            string=
                string.substring(0, start) + content + string.substring(end);
        }
        // write the file on disk
        IO.writeFile(string, file);
    }
}
