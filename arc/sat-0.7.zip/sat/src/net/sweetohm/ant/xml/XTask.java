/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.sweetohm.ant.xml;

import java.io.File;
import java.util.Vector;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import net.sweetohm.ant.util.Arg;
import net.sweetohm.ant.util.FileTask;
import org.apache.tools.ant.BuildException;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Parser;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.jclark.xsl.sax.FileDestination;
import com.jclark.xsl.sax.OutputMethodHandlerImpl;
import com.jclark.xsl.sax.XSLProcessorImpl;

/**
 * XTask is an XSLT task using XT from James Clark.
 *
 * @author Michel CASABIANCA
 */
public class XTask extends FileTask implements ErrorHandler {

    /**
     * XT processor. This field is static because only one processor is
     * necessary. Should be reseted between calls ?
     */
    static XSLProcessorImpl xslprocessor;
    /** Output handler for the XT processor */
    static OutputMethodHandlerImpl handler;
    /** The stylesheet to use to process files */
    String style;
    /** The destination directory for transformed files */
    String todir;
    /**
     * The transformed file. This should be set only for the transformation
     * of a single file
     */
    String tofile;
    /** Extension for processed files (defaults to .html) */
    String extension= ".html";
    /** The argument list */
    Vector args= new Vector();
    /**
     * Force flag. When it is set to true, the transformation is made even
     * if the generated file is newer than the XML and XSLT files
     */
    boolean force= false;

    /**
     * Setter for the stylesheet to use for processing.
     *
     * @param style The stylesheet to use.
     */
    public void setStyle(String style) {
        this.style= style;
    }

    /**
     * Setter for the output directory for processed files.
     *
     * @param todir The directory for processed files.
     */
    public void setTodir(String todir) {
        this.todir= todir;
    }

    /**
     * Setter for the destination file.
     *
     * @param tofile The processed files.
     */
    public void setTofile(String tofile) {
        this.tofile= tofile;
    }

    /**
     * Extension setter.
     *
     * @param extension The extension to append to the generated file.
     */
    public void setExtension(String extension) {
        this.extension= extension;
    }

    /**
     * Add an argument for the processor.
     *
     * @param arg The argument to pass to the processor.
     */
    public void addArg(Arg arg) {
        args.addElement(arg);
    }

    /**
     * Setter for the force flag.
     *
     * @param force The force tag. If <code>true</code>, the file is
     * generated even if the xml or xsl are older.
     */
    public void setForce(boolean force) {
        this.force= force;
    }

    /**
     * Executes the task.
     */
    public void execute() throws BuildException {
        // build File objects
        File style= null;
        if (this.style != null)
            style= getProject().resolveFile(this.style);
        File todir= null;
        if (this.todir != null)
            todir= getProject().resolveFile(this.todir);
        File tofile= null;
        if (this.tofile != null)
            tofile= getProject().resolveFile(this.tofile);
        // check attributes
        if (style == null)
            throw new BuildException("Style attribute is mandatory.");
        else if (!style.exists())
            throw new BuildException("Style sheet " + style + " not found.");
        if (tofile != null && !tofile.getParentFile().exists())
            throw new BuildException(
                "Directory " + tofile.getParent() + " not found.");
        if (todir != null && !todir.exists())
            throw new BuildException("Directory " + todir + " not found.");
        // create XSLT processor
        if (xslprocessor == null) {
            xslprocessor= new XSLProcessorImpl();
            xslprocessor.setParser(getParser());
            xslprocessor.setErrorHandler(this);
            handler= new OutputMethodHandlerImpl(xslprocessor);
            xslprocessor.setOutputMethodHandler(handler);
        }
        // pass argument to the processor
        for (int i= 0; i < args.size(); i++) {
            Arg arg= (Arg) args.elementAt(i);
            xslprocessor.setParameter(arg.getName(), arg.getValue());
        }
        // get the XSL stylesheet date
        long xslDate= style.lastModified();
        // get files to process
        Vector files= getFiles(true);
        // loop on files to process
        for (int i= 0; i < files.size(); i++) {
            try {
                // extract the XML file
                File file= (File) files.elementAt(i);
                long xmlDate= file.lastModified();
                // get input sources for xml and xsl files
                InputSource xmlSource= getInputSource(file);
                InputSource xslSource= getInputSource(style);
                // test if destination file name is set
                if (tofile == null) {
                    // build the destination file name
                    String name= file.getName();
                    if (name.indexOf(".") >= 0)
                        name=
                            name.substring(0, name.lastIndexOf("."))
                                + extension;
                    tofile= new File(todir, name);
                }
                long toDate= tofile.lastModified();
                // test if the transformation should be done
                if (toDate < xslDate || toDate < xmlDate || force) {
                    // write a message on the console
                    log("Transforming: " + file.getPath());
                    // set the destination
                    handler.setDestination(new FileDestination(tofile));
                    // load the style sheet
                    xslprocessor.loadStylesheet(xslSource);
                    // parse the document
                    xslprocessor.parse(xmlSource);
                }
                // reset destination file
                tofile= null;
            } catch (Exception e) {
                throw new BuildException(e.getMessage());
            }
        }
    }

    /**
     * Builds the SAX parser for XT. The <code>Parser</code> class is
     * deprecated, but XT only knows anout those parsers. Note that the 
     * <code>Parser</code> class is deprecated, but we have no choice as
     * XT uses it.
     *
     * @return the built parser
     */
    protected static Parser getParser() {
        try {
            // get the parser factory
            SAXParserFactory factory= SAXParserFactory.newInstance();
            // set the parser non validating
            factory.setValidating(false);
            // get the SAX parser
            SAXParser saxParser= factory.newSAXParser();
            // return the parser
            return saxParser.getParser();
        } catch (Exception e) {
            throw new BuildException(e.getMessage());
        }
    }

    /**
     * Creates imput source
     *
     * @param fileName the file name for this source
     * @return the build input source
     */
    protected static InputSource getInputSource(File file) {
        return new InputSource("file://" + file.getAbsolutePath());
    }

    /**
     * Manage warnings. Implements ErrorHandler interface.
     */
    public void warning(SAXParseException e) {
        printSAXParseException(e);
    }

    /**
     * Manage errors. Implements ErrorHandler interface.
     */
    public void error(SAXParseException e) {
        printSAXParseException(e);
    }

    /**
     * Manage fatal errors. Implements ErrorHandler interface.
     */
    public void fatalError(SAXParseException e) throws SAXException {
        throw e;
    }

    /**
     * Print the SAX error message.
     */
    void printSAXParseException(SAXParseException e) {
        // get error info
        String systemId= e.getSystemId();
        int lineNumber= e.getLineNumber();
        String message= "";
        // add info if present
        if (systemId != null)
            message += systemId + ":";
        if (lineNumber >= 0)
            message += lineNumber + ":";
        if (systemId != null || lineNumber >= 0)
            message += " ";
        // print the error message
        log(message + e.getMessage());
    }
}
