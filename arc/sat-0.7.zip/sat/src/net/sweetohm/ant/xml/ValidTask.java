/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.sweetohm.ant.xml;

import java.io.File;
import java.io.IOException;
import java.util.Vector;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import net.sweetohm.ant.util.FileTask;
import org.apache.tools.ant.BuildException;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Valid is an XML validator (can check well formness and validity).
 *
 * @author Michel CASABIANCA
 * @version 1.0
 */
public class ValidTask extends FileTask {

    /** DTD loading flag */
    boolean dtd= true;
    /** Fail on error flag. If true, the ant compilation stops on error */
    boolean failonerror= true;
    /**
     * The error level to generate an error:
     * - warning [0]: a warning is an error (shown and may stop processing).
     * - error [1]: same for errors.
     * - fatal [2]: is the default value.
     */
    static final int WARNING= 0;
    static final int ERROR= 1;
    static final int FATAL= 2;
    int errorlevel= FATAL;
    /** The file prefix for system ID */
    static final String FILE= "file:";
    /** The number of errors */
    int errorCount= 0;
    /** The maximum number of errors */
    int maxerrors= 100;

    /**
     * Setter for the DTD loading. If true, the DTD is loaded for validation.
     * Defaults to true.
     *
     * @param dtd a <code>boolean</code> value
     */
    public void setDtd(boolean dtd) {
        this.dtd= dtd;
    }

    /**
     * Setter for the failonerror flag.If true, the Ant compilation stops
     * with an error message if the document being validated is not valid.
     * Defaults to true.
     *
     * @param failonerror Flag for failonerror flag.
     */
    public void setFailonerror(boolean failonerror) {
        this.failonerror= failonerror;
    }

    /**
     * Error level setter (possible values are 'warning', 'error' or 'fatal').
     * The default value is 'fatal'.
     *
     * @param errorlevel The error level.
     */
    public void setErrorlevel(String errorlevel) {
        if (errorlevel.equals("warning"))
            this.errorlevel= WARNING;
        else if (errorlevel.equals("error"))
            this.errorlevel= ERROR;
        else if (errorlevel.equals("fatal"))
            this.errorlevel= FATAL;
        else
            throw new BuildException(
                "Illegal error level (possible values are "
                    + "'warning', 'error' or 'fatal')");
    }

    /**
     * Maximum errors setter.
     *
     * @param maxerrors The maximum number of errors to display for
     * a given file.
     */
    public void setMaxerrors(String maxerrors) {
        // convert the string in integer
        try {
            this.maxerrors= Integer.parseInt(maxerrors);
        } catch (NumberFormatException e) {
            throw new BuildException(
                "The value of attribute 'maxerrors' "
                    + "should be an integer.");
        }
        // test the range
        if (this.maxerrors < 1)
            throw new BuildException(
                "Max number of errors must be greater " + "than 0.");
    }

    /**
     * Executes the task.
     *
     * @exception BuildException if an error occurs
     */
    public void execute() throws BuildException {
        // instantiate the parser
        SAXParser parser= getParser();
        // instantiate the handler
        Handler handler= new Handler();
        // get the files to process
        Vector files= getFiles(true);
        // loop on the files
        for (int i= 0; i < files.size(); i++) {
            // get the next file
            File file= (File) files.elementAt(i);
            // informative message
            log("Validating file '" + file.getName() + "'...");
            // parse the file
            try {
                parser.parse(file, handler);
            }
            // catch interrupted parsing exception
            catch (SAXParsingInterruptedException e) {
                log(e.getMessage());
                if (failonerror)
                    throw new BuildException("Parsing error.");
            }
            // catch an unknown parse exception
            catch (SAXException e) {
                throw new BuildException("Unknown error while parsing.");
            }
            // catch an IO exception
            catch (IOException e) {
                throw new BuildException("IO error while parsing.");
            }
            // if an error occured, test failonerror
            if (errorCount > 0 && failonerror)
                throw new BuildException("Parsing error.");
        }
    }

    /**
     * Builds the SAX parser for parsing.
     *
     * @return The built parser
     */
    SAXParser getParser() {
        try {
            // get the parser factory
            SAXParserFactory factory= SAXParserFactory.newInstance();
            // set the parser non validating
            factory.setValidating(dtd);
            // get the SAX parser
            return factory.newSAXParser();
        } catch (Exception e) {
            throw new BuildException(e.getMessage());
        }
    }

    /**
     * A class to handle parsing errors.
     */
    class Handler extends DefaultHandler {

        /**
         * Manage warnings. Implements ErrorHandler interface.
         */
        public void warning(SAXParseException e) throws SAXException {
            if (errorlevel <= WARNING)
                printError(e);
        }

        /**
         * Manage errors. Implements ErrorHandler interface.
         */
        public void error(SAXParseException e) throws SAXException {
            if (errorlevel <= ERROR)
                printError(e);
        }

        /**
         * Manage fatal errors. Implements ErrorHandler interface.
         */
        public void fatalError(SAXParseException e) throws SAXException {
            printError(e);
        }

        /**
         * Print and register the error.
         */
        void printError(SAXParseException e) throws SAXException {
            // register the error
            errorCount++;
            // test if the number of error is greater than the limit
            if (errorCount > maxerrors) // interrupt parsing
                throw new SAXParsingInterruptedException();
            // get error info
            String systemId= e.getSystemId();
            // remove "file:" from systemId
            if (systemId.startsWith(FILE))
                systemId= systemId.substring(FILE.length());
            int lineNumber= e.getLineNumber();
            String message= "";
            // add info if present
            if (systemId != null)
                message += systemId + ":";
            if (lineNumber >= 0)
                message += lineNumber + ":";
            if (systemId != null || lineNumber >= 0)
                message += " ";
            // print the error message
            log(message + e.getMessage());
        }
    }

    /**
     * This exception is thrown when the parsing is interrupted due to
     * to a number of errors greater than the allowed maximum.
     */
    class SAXParsingInterruptedException extends SAXException {

        /**
         * Creates a new <code>SAXParsingInterruptedException</code> instance.
         * Simply fill the message.
         */
        SAXParsingInterruptedException() {
            super("Parsing interrupted.");
        }
    }
}
