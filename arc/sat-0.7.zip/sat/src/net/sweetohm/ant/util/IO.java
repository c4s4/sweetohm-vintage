/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.sweetohm.ant.util;

import java.io.*;
import java.util.*;

/**
 * This class is an utility class for IO.
 *
 * @author <a href="mailto:casa@sweetohm.net">Michel CASABIANCA</a>
 * @version 1.0
 */
public class IO {

    /** The default encoding (ASCII) */
    static final String DEFAULT_ENCODING= "ascii";
    /** The XML header start */
    static final String XML_HEADER_START= "<?xml";
    /** The XML header end */
    static final String XML_HEADER_END= "?>";
    /** Separator characters */
    static final String BLANKS= " \t\n";
    /** The version attribute */
    static final String VERSION_ATT= "version";
    /** The version value */
    static final String VERSION_VAL= "1.0";
    /** The encoding attribute */
    static final String ENCODING_ATT= "encoding";

    /**
     * Read a file.
     *
     * @param file The file to read
     * @return The content of the file as a String
     */
    public static String loadFile(File file) throws IOException {
        // build streams
        FileReader in= new FileReader(file);
        StringWriter out= new StringWriter();
        // loop to read to file
        char[] buffer= new char[4096];
        int len= -1;
        while ((len= in.read(buffer, 0, buffer.length)) >= 0)
            out.write(buffer, 0, len);
        // close the streams
        in.close();
        out.flush();
        out.close();
        // return the String
        return out.toString();
    }

    /**
     * Read a file using a given encoding.
     *
     * @param file The file to read
     * @param encoding The encoding to read the file
     * @return The content of the file as a String
     */
    public static String loadFile(File file, String encoding)
        throws IOException {
        // build streams
        InputStreamReader in=
            new InputStreamReader(new FileInputStream(file), encoding);
        StringWriter out= new StringWriter();
        // loop to read to file
        char[] buffer= new char[4096];
        int len= -1;
        while ((len= in.read(buffer, 0, buffer.length)) >= 0)
            out.write(buffer, 0, len);
        // close the streams
        in.close();
        out.flush();
        out.close();
        // return the String
        return out.toString();
    }

    /**
     * Read an XML file. This method takes care of encoding of the loaded
     * file by reading the first line to determine the file encoding.
     *
     * @param file The file to read.
     * @return The content of the file as a String.
     */
    public static String loadXMLFile(File file) throws IOException {
        String encoding= getXMLFileEncoding(file);
        return loadFile(file, encoding);
    }

    /**
     * Return the encoding of an XML file. Return default encoding (ascii)
     * if no encoding was set in the XML header.
     *
     * @param file The XML file to read.
     * @return The encoding of the file as stated in the XML header.
     */
    public static String getXMLFileEncoding(File file) throws IOException {
        String encoding= DEFAULT_ENCODING;
        Reader in= null;
        try {
            in= new InputStreamReader(new FileInputStream(file), encoding);
            StringBuffer buffer= new StringBuffer();
            int character= -1;
            while ((character= in.read()) > -1 && character != '\n')
                buffer.append((char) character);
            String header= buffer.toString();
            encoding= parseXMLHeader(header);
        } finally {
            if (in != null)
                in.close();
        }
        return encoding;
    }

    /**
     * Parse XML header to:
     * <ul>
     * <li>Check that this is an XML header.
     * <li>Check the the version is 1.0.
     * <li>Return encoding (<code>null</code> if no encoding in header).
     * </ul>
     *
     * @param header a <code>String</code> value
     * @return a <code>String</code> value
     * @exception IOException if an error occurs (no XML header or bad 
     * XML version).
     */
    static String parseXMLHeader(String header) throws IOException {
        String encoding= null;
        header= header.trim();
        if (!header.startsWith(XML_HEADER_START)
            || !header.endsWith(XML_HEADER_END))
            throw new IOException("Not an XML file");
        StringTokenizer st= new StringTokenizer(header, BLANKS);
        while (st.hasMoreTokens()) {
            String token= st.nextToken();
            if (token.equals(XML_HEADER_START))
                continue;
            if (token.endsWith(XML_HEADER_END))
                token= token.substring(0, token.lastIndexOf(XML_HEADER_END));
            int pos= token.indexOf("=");
            String attribute= token.substring(0, pos);
            String quote= token.substring(pos + 1, pos + 2);
            String value=
                token.substring(
                    token.indexOf(quote) + 1,
                    token.lastIndexOf(quote));
            // test the XML version
            if (attribute.equals(VERSION_ATT) && !value.equals(VERSION_VAL))
                throw new IOException("Bad XML version, should be 1.0");
            else if (attribute.equals(ENCODING_ATT))
                encoding= value;
        }
        return (encoding == null ? DEFAULT_ENCODING : encoding);
    }

    /**
     * Write a String into a file.
     *
     * @param string the string to write
     * @param file The file to write
     */
    public static void writeFile(String string, File file) throws IOException {
        // build streams
        FileWriter out= new FileWriter(file);
        // loop to write the String
        out.write(string);
        // close the streams
        out.flush();
        out.close();
    }

    /**
     * Write a String into a file using a given encoding.
     *
     * @param string the string to write
     * @param file The file to write
     * @param encoding The encoding to use to write the file.
     * @exception IOException if an error occurs
     */
    public static void writeFile(String string, File file, String encoding)
        throws IOException {
        // build streams
        OutputStreamWriter out=
            new OutputStreamWriter(new FileOutputStream(file), encoding);
        // loop to write the String
        out.write(string);
        // close the streams
        out.flush();
        out.close();
    }

    /**
     * Test method.
     *
     * @param args Command line arguments as a <code>String[]</code>.
     * This should be the file to read.
     */
    public static void main(String[] args) throws Exception {
        //System.out.println(getXMLFileEncoding(new File(args[0])));
        System.out.println(loadXMLFile(new File(args[0])));
    }
}
