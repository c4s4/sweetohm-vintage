/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.sweetohm.ant.server;

import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

/**
 * This task runs a server to handle build requests send by sockets.
 *
 * @author <a href="mailto:casa@sweetohm.net">Michel CASABIANCA</a>
 * @version 1.0
 */
public class ServerTask extends Task implements Runnable {

    /** The thread that is running */
    Thread thread;
    /** The port the server is listening to */
    int port= 5393;
    /** List of allowed IPs for connection */
    List ips= new ArrayList();
    /** The project to build */
    Project project;
    /** The server socket to listen port */
    ServerSocket server;

    /**
     * Empty constructor.
     */
    public ServerTask() {
        // set localhost as default value for the IP list
        ips.add("127.0.0.1");
    }

    /**
     * Set the port the server is listening.
     *
     * @param port The port the server is listening.
     */
    public void setPort(int port) {
        this.port= port;
    }

    /**
     * Set the list of granted IPs for connection.
     *
     * @param ips The coma separated list of IPs.
     */
    public void setIps(String ips) {
        this.ips= new ArrayList();
        StringTokenizer st= new StringTokenizer(ips, ",");
        while (st.hasMoreTokens()) {
            this.ips.add(st.nextToken().trim());
        }
    }

    /**
     * Lauch the server for Ant management, ant wait for shutdown. If the
     * server is already running, skip the task.
     */
    public void execute() {
        if (thread == null) {
            project= getProject();
            start();
            while (thread != null) {
                try {
                    Thread.currentThread().sleep(1000);
                } catch (InterruptedException e) {
                    thread= null;
                }
            }
        } else {
            log("Server already running, skip");
        }
    }

    /**
     * The main loop of the server.
     */
    public void run() {
        RequestHandler handler= null;
        // server startup
        try {
            server= new ServerSocket(port);
            handler= new RequestHandler(project, this);
            log("Server running and listening on port " + port);
        } catch (BindException e) {
            log(
                "Server could not bind on port "
                    + port
                    + ": "
                    + e.getMessage());
            thread= null;
        } catch (Exception e) {
            log("Server could not start: " + e.getMessage());
            thread= null;
        }
        // server loop
        while (thread != null) {
            Socket socket= null;
            try {
                socket= server.accept();
                log("");
                log("Request from: " + socket.getInetAddress());
                if (checkAccess(socket))
                    handler.handle(socket);
                else
                    log("Error: Unauthorized access");
            } catch (InterruptedException e) {
                log("Server shutdown");
                thread= null;
            } catch (Exception e) {
                log("Error: " + e.getMessage());
                thread= null;
            } finally {
                try {
                    socket.close();
                } catch (Exception e) {
                    log("Error: " + e.getMessage());
                }
            }
        }
    }

    /**
     * Start the server.
     */
    public void start() {
        thread= new Thread(this);
        thread.start();
    }

    /**
     * Stop the server.
     */
    public void stop() {
        thread= null;
    }

    /**
     * Check that the access is granted by searching the IP of the client in 
     * the list of granted IPs. Return <code>true</code> if access is granted
     * and <code>false</code> if it is not.
     *
     * @param socket The <code>Socket</code> for the connection.
     * @exception SecurityException if access is not granted for this IP.
     */
    boolean checkAccess(Socket socket) throws SecurityException {
        byte[] ip= socket.getInetAddress().getAddress();
        String ipString=
            Byte.toString(ip[0])
                + "."
                + Byte.toString(ip[1])
                + "."
                + Byte.toString(ip[2])
                + "."
                + Byte.toString(ip[3]);
        return ips.contains(ipString);
    }
}
