/*
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2000 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" must
 *    not be used to endorse or promote products derived from this
 *    software without prior written permission. For written
 *    permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    nor may "Apache" appear in their name, without prior written
 *    permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

package net.sweetohm.ant.server;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.tools.ant.BuildEvent;
import org.apache.tools.ant.BuildListener;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

/**
 * This class handles requests for Ant and process them.
 *
 * @author <a href="mailto:casa@sweetohm.net">Michel CASABIANCA</a>
 * @version 1.0
 */
public class RequestHandler implements BuildListener {

    /** The running project */
    Project project;
    /** The running task */
    Task task;
    /** The out writer */
    Writer out;
    /** Blank characters */
    static final String BLANKS= " \t\n";
    /** The package name for commands */
    static final String COMMAND_PACKAGE= "net.sweetohm.ant.server.command";

    /**
     * Creates a new <code>RequestHandler</code> instance.
     *
     * @param project The running Ant <code>Project</code>.
     */
    public RequestHandler(Project project, Task task) {
        this.project= project;
        this.task= task;
    }

    /**
     * Method to handle requests.
     *
     * @param socket The <code>Socket</code> to read and write.
     */
    public void handle(Socket socket) throws InterruptedException {
        try {
            Reader in= new InputStreamReader(socket.getInputStream());
            out= new OutputStreamWriter(socket.getOutputStream());
            StringBuffer command= new StringBuffer();
            int i= -1;
            while ((i= in.read()) > -1) {
                char c= (char) i;
                if (c == '\n') {
                    process(command.toString());
                    break;
                } else
                    command.append(c);
            }
            socket.close();
        } catch (InterruptedException e) {
            throw e;
        } catch (Exception e) {
            task.log("\nError: " + e.getMessage());
        } finally {
            try {
                socket.close();
            } catch (IOException e) {} finally {
                out= null;
            }
        }
    }

    /**
     * Process a command.
     *
     * @param command The command to process as a <code>String</code>.
     * @exception InterruptedException To stop the server, this is not an
     * error !
     */
    void process(String commandLine) throws InterruptedException, IOException {
        // log command
        task.log("Processing command: " + commandLine);
        // get the command to process
        StringTokenizer st= new StringTokenizer(commandLine.trim(), BLANKS);
        String command= st.nextToken();
        // get argument list
        List args= new ArrayList();
        while (st.hasMoreTokens()) {
            args.add(st.nextToken());
        }
        // invoke the command implementation
        try {
            project.addBuildListener(this);
            Class commandClass= Class.forName(getClassName(command));
            Class[] argTypes= { List.class, Project.class, Writer.class };
            Method method= commandClass.getMethod("execute", argTypes);
            Object[] argObjects= { args, project, out };
            method.invoke(null, argObjects);
            project.removeBuildListener(this);
            task.log("OK");
        } catch (ClassNotFoundException e) {
            task.log("Error: Command "+command+" not found");
        } catch (InvocationTargetException e) {
            Throwable nested= e.getTargetException();
            if (nested != null && nested instanceof InterruptedException)
                throw (InterruptedException) nested;
            if (nested != null)
                task.log("Error: " + nested.getMessage());
            else
                task.log("Error");
        } catch (Exception e) {
            task.log("Error: " + e.getMessage());
        } finally {
            project.removeBuildListener(this);
        }
        out.flush();
    }

    /**
     * Return the class name for a given command. For instance, il the
     * command is help, the class name is Help. Append also the package
     * name for commands.
     *
     * @param command The command.
     * @return The class name.
     */
    String getClassName(String command) {
        return COMMAND_PACKAGE
            + "."
            + command.substring(0, 1).toUpperCase()
            + command.substring(1);
    }

    /**
     * Send a message to the client.
     *
     * @param message a <code>String</code> value
     */
    void send(String message) {
        if (out != null) {
            try {
                out.write(message);
                out.flush();
            } catch (IOException e) {
                // TODO: do something !
            }
        }
    }

    /**
     *  Fired before any targets are started.
     */
    public void buildStarted(BuildEvent event) {}

    /**
     *  Fired after the last target has finished. This event
     *  will still be thrown if an error occured during the build.
     *
     *  @see BuildEvent#getException()
     */
    public void buildFinished(BuildEvent event) {}

    /**
     *  Fired when a target is started.
     *
     *  @see BuildEvent#getTarget()
     */
    public void targetStarted(BuildEvent event) {
        send(event.getTarget() + ":\n");
    }

    /**
     *  Fired when a target has finished. This event will
     *  still be thrown if an error occured during the build.
     *
     *  @see BuildEvent#getException()
     */
    public void targetFinished(BuildEvent event) {
        send("\n");
    }

    /**
     *  Fired when a task is started.
     *
     *  @see BuildEvent#getTask()
     */
    public void taskStarted(BuildEvent event) {}

    /**
     *  Fired when a task has finished. This event will still
     *  be throw if an error occured during the build.
     *
     *  @see BuildEvent#getException()
     */
    public void taskFinished(BuildEvent event) {}

    /**
     *  Fired whenever a message is logged.
     *
     *  @see BuildEvent#getMessage()
     *  @see BuildEvent#getPriority()
     */
    public void messageLogged(BuildEvent event) {
        if (event.getPriority() < 3) {
            send(event.getMessage() + "\n");
        }
    }
}
